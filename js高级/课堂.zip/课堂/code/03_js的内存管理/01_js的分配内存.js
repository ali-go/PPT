var name = "why"
var obj = {name: "why", age: 18}

function foo() {
  
}
