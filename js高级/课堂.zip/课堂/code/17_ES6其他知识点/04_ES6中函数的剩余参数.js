// function foo(...args, m, n) {
//   console.log(m, n)
//   console.log(args)

//   console.log(arguments)
// }

// foo(20, 30, 40, 50, 60)


// rest paramaters必须放到最后
// Rest parameter must be last formal parameter

// function foo(m, n = m + 1) {
//   console.log(m, n)
// }

// foo(10);
