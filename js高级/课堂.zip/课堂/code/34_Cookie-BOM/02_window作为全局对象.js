var message = "Coderwhy"
var age = 18

window.setTimeout(() => {
  console.log("setTimeout")
}, 2000);

const obj = new window.Date()
console.log(obj)
