console.log("ddd")

require("./eee")


