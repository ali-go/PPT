console.log("main.js代码开始运行")

require("./foo")
require("./foo")
require("./foo")

console.log("main.js代码后续运行")
