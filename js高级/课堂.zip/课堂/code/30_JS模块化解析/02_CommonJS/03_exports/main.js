const why = require("./why.js")

console.log(why.name)
console.log(why.age)
console.log(why.sum(20, 30))
