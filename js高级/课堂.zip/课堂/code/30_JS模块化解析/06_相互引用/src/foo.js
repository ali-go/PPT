const name = "foo"
const age = 18

// commonjs导出
module.exports = {
  name,
  age
}
