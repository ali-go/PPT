var moduleB = (function() {
  var name = "why"
  var isFlag = false

  return {
    name: name,
    isFlag: isFlag
  }
})()
