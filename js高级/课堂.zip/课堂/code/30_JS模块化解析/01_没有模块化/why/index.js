var moduleA = (function() {
  var name = "why"
  var age = 18
  var isFlag = true

  return {
    name: name,
    isFlag: isFlag
  }
})()
