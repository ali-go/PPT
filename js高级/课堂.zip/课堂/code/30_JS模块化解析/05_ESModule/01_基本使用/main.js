import { name, age } from "./foo.js"

console.log(name)
console.log(age)
