// import { add, sub } from './utils/math.js'
// import { priceFormat, timeFormat } from './utils/format.js'

import { add, sub, priceFormat, timeFormat } from './utils/index.js'

console.log(add(10, 20))
console.log(sub(10, 20))
console.log(priceFormat())
console.log(timeFormat())
