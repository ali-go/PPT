const name = "why"
const age = 18

const foo = "foo value"

export {
  name,
  age,
  foo
}

