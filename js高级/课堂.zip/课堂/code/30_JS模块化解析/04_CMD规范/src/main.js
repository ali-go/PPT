define(function(require, exports, module) {
  const foo = require("./foo")
  console.log("main:", foo)
})
