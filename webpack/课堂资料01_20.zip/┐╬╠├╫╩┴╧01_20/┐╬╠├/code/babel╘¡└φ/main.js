const name = "coderwhy";
const foo = (name) => console.log(name);
foo(name);