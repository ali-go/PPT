const message = 'Hello TypeScript';

const foo = (info) => {
  console.log(info);
};

foo('abc');

export {};
