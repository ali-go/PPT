const dateFormat = (date) => {
  return "2020-12-12";
}

const priceFormat = (price) => {
  return "100.00";
}

// console.log(cba);

module.exports = {
  dateFormat,
  priceFormat
}
