import { sum, mul } from "./js/math";

console.log(mul(20, 30));
console.log(sum(20, 30));
