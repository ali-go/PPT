"use strict";

var message = "Hello World";

var foo = function foo(info) {
  console.log(info);
};

foo(message);