export function dateFormat(date: string) {
  return "2020-10-10";
}