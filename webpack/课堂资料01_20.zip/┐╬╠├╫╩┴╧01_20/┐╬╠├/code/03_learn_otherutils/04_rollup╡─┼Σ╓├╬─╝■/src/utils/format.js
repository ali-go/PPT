function dateFormat() {
  return "2020-10-10";
}

module.exports = {
  dateFormat
}
