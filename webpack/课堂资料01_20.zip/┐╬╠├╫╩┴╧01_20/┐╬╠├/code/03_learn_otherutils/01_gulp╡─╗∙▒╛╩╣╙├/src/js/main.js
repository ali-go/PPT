const message = "Hello World";
console.log(message);

const foo = () => {
  console.log("foo");
}

foo();

console.log("Hello World");
