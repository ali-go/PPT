
const message = "Hello World";
console.log(message);

const sum = (num1, num2) => {
  return num1 + num2;
}

console.log(sum(20, 30));

console.log("哈哈哈~");
console.log("heheheh");
