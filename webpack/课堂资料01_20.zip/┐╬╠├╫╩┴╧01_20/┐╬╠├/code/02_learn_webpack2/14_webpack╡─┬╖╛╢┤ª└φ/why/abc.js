console.log("why文件下的dna.js");

