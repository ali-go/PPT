export function abc() {
  return "abc";
}

const titleDiv = document.createElement('div');
titleDiv.className = "title";
document.body.appendChild(titleDiv);

const h2El = document.createElement('h2');
document.body.appendChild(h2El);
