import { sum } from './math';

import "./format";
import("./abc").then(res => {
  
});
import "./style.css";

console.log(sum(20, 30));

console.log(window.abc);


