// 纯模块

export function dateFormat() {
  return "2021-10-10";
}

export function priceFormat() {
  return "200.88";
}

// window.abc = "abc";

