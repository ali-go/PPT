import _ from 'lodash';
import dayjs from 'dayjs';

import "./request";
import "./style.css";

console.log("Hello Main");
console.log(_.join(["Hello", "Main"]));
console.log(dayjs(), "Main");
