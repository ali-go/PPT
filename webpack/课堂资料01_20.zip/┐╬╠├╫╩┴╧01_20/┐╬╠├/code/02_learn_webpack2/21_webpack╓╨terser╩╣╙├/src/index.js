import {sum, mul} from "./math";

import _ from "lodash";

console.log(sum(20, 30));
console.log(mul(20, 30));

