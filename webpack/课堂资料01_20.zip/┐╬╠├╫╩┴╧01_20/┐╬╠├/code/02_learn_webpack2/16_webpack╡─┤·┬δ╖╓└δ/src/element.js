const element = document.createElement('div');

element.innerHTML = "Hello Element";

export default element;