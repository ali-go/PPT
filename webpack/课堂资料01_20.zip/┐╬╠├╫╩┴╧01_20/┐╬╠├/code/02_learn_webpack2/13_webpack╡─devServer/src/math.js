
export function sum(num1, num2) {
  console.log(num1 + num2);
}

console.log("Hello Math Utils eeeee");
