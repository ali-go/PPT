import "./style.css";

console.log("indexaaaaaccccc");
