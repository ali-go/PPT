
console.log("indexaaaabbbbbcccc");
