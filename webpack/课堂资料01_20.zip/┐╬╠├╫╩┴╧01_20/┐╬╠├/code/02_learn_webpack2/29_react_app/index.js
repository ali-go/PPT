const names = [undefined, false, "abc", ""].filter(Boolean);

console.log(names);
