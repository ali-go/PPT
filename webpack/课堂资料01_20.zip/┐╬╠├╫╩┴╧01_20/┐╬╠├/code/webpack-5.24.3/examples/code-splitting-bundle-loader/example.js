require("bundle-loader!./file.js")(function(fileJsExports) {
	console.log(fileJsExports);
});
