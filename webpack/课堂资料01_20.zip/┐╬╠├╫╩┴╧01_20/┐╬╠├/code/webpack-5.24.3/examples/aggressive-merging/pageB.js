require(["./common"], function(common) {
	common(require("./b"));
});