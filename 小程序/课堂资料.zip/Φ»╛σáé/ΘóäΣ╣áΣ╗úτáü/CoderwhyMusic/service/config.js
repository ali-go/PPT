const BASE_URL = "http://123.207.32.32:9001"
const TIMEOUT = 10000

export {
 BASE_URL,
 TIMEOUT
}
