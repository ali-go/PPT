const audioContext = wx.createInnerAudioContext()

export {
  audioContext
}
