module.exports = {
  // db uri
  db: 'mongodb://localhost:20567/mina',
  // Setting port for server
  port: 3000,
  host: 'http://0.0.0.0:3000',
  jwtSecret: 'myjwtsecret',
  appId:'wx44a8878d2bb8c7d8',
  appSecret:'eb8f16b98652cd831bc68cb9063ff61f'
}
