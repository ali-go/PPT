console.log(process.argv[2]);
console.log(process.argv[3]);



process.argv.forEach(item => {
  console.log(item);
})



