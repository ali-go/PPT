const foo = require('./module/foo.mjs');

console.log(foo);
