const name = "coderwhy";

module.exports = {
  name
}