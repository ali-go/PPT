// 1000行

console.log(moduleBar.name);
console.log(moduleBar.age);
