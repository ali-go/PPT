const name = 'why';
const age = 18;

export {
  name,
  age
}
