import { name, age } from './modules/foo.mjs';

console.log(name);
console.log(age);
