import path from 'path';

const basepath = '../User/why';
const filename = '/abc.txt';
const othername = '/why.js';

const filepath1 = path.join(basepath, filename);
console.log(filepath1);

